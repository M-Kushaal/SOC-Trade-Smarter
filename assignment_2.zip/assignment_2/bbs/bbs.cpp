#include <vector>
#include <cmath>
#include "boilinger_bands.h"
using namespace std;

double mean(vector<Candle> &candles, int index){
    double sum=0;

    for(int i=index-19;i<=index;i++){
        sum+=candles[i].close;
    }

    return sum/20;

}

double std_dev(vector<Candle> &candles, int index){

    mean(candles,index);

    double var=0;
    for(int i=index-19;i<=index;i++){
        var+=(candles[i].close-mean(candles,i))*(candles[i].close-mean(candles,i));
    }

    return sqrt(var/20);
}

TradeResult bbs_implementation (vector<Candle> &candles, double profit_threshold){

    vector<double> closes;
    
    for(auto i: candles){
        closes.push_back(i.close);
    }

    enum States { NONE, LONG, SHORT };
    States state = NONE;
    double entry = 0, profit = 0, total = 0;
    int trades = 0, profitable_profits = 0;


    for(int i=20;i<closes.size();i++){

        double sma_20 = mean(candles,i);
        double upper_band = sma_20 + 2*std_dev(candles,i);
        double lower_band = sma_20 - 2*std_dev(candles,i);

        if(closes[i]>=upper_band && state ==NONE){
                state=SHORT;
                entry=closes[i];
        }
        else if(state==SHORT && closes[i]<=sma_20){
                state=NONE;
                profit = entry - closes[i];

                total+=profit;
                if(profit>profit_threshold) profitable_profits++;
                trades++;
        }

        else if (state==NONE && closes[i]<=lower_band){
                state=SHORT;
                entry=closes[i];
        }
        
        else if(state==LONG && closes[i]>=sma_20){
                state=NONE;
                profit = entry - closes[i];

                total+=profit;
                if(profit>profit_threshold) profitable_profits++;
                trades++;
        }
    }


    if(state==SHORT){
        state=NONE;
        profit = entry - closes.back();

        total+=profit;
        if(profit>profit_threshold) profitable_profits++;
        trades++;
    }

    if(state==LONG){
        state=NONE;
        profit = closes.back() - entry;

        total+=profit;
        if(profit>profit_threshold) profitable_profits++;
        trades++;
    }

    double success_rate = trades>0 ? profitable_profits*100/trades : 0;
    double avg_returns = total/trades;

    return {success_rate,avg_returns,trades,total};

}

