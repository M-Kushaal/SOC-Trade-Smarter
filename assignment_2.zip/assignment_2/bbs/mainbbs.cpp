#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <iostream>
#include "boilinger_bands.h"

using namespace std;

vector<Candle> read_csv(const string& filename) {
    vector<Candle> candles;
    ifstream file(filename);
    string line, header;
    
    getline(file, header); // Skip header row
    
    while (getline(file, line)) {
    stringstream ss(line);
    string date, open, high, low, close, adj_close, volume;

    getline(ss, date, ',');
    getline(ss, close, ',');
    getline(ss, high, ',');
    getline(ss, low, ',');
    getline(ss, open, ',');
    getline(ss, volume, ',');

    try {
        candles.push_back(Candle{
            date,
            stod(open),
            stod(high),
            stod(low),
            stod(close)
        });
    } catch (const std::exception& e) {
        cerr << "Error on line: " << line << "\n";
        cerr << "Reason: " << e.what() << "\n";
    }
}

    
    return candles;
}

int main() {
    // 1. Load data from CSV
        
    vector<Candle> candles = read_csv("AAPL.csv");
    
    // 2. Run MACD strategy
    double profit_threshold = 0.0; // Adjust as needed
    TradeResult result = bbs_implementation(candles, profit_threshold);
    
    // 3. Print results
    cout << "Success Rate: " << result.success_rate << "%" << endl;
    cout << "Avg Return per Trade: " << result.avg_returns << endl;
    cout << "Total Trades: " << result.trades << endl;
    cout << "Net Profit/Loss: " << result.total << endl;
    
    return 0;
}



