#ifndef SMA_H
#define SMA_H

#include <vector>
#include <string>

using namespace std;

struct Candle {string date; double open; double high; double low; double close; };

struct TradeResult {
    double success_rate;
    double avg_returns;
    int trades;
    double total;
};

TradeResult sma_implementation(vector<Candle>& candles, double profit_threshold);

#endif


