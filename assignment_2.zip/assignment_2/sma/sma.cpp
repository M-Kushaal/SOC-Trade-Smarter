/*int ema(vector<double> values,int index,int period){
    
    if(index<period){
        
        double sum=0; 
        for(int i=0;i<index;i++){
            sum+=values[i];
        }
        return sum/index;

    }

    else{
        double sum=0; 
        for(int i=0;i<index;i++){
            sum+=values[i];
        }
        return sum/index;
    }
}
*/

#include <vector>
#include "sma.h"
using namespace std;

TradeResult sma_implementation (vector<Candle> &candles, double profit_threshold){

    vector<double> closes;
    
    for(auto i: candles){
        closes.push_back(i.close);
    }

    vector<double> sma_s(closes.size(), 0);
    vector<double> sma_l(closes.size(), 0);
    vector<double> sum_s(closes.size(), 0);
    vector<double> sum_l(closes.size(), 0);
    
    int small_length = 50;
    int long_length= 200;

    double temp_sum=0;
    for(int i=0;i<small_length;i++){
        temp_sum+=closes[i];
    }

    sum_s[small_length-1] = temp_sum;
    sma_s[small_length-1] = temp_sum/small_length;

    
    for(int i=small_length;i<long_length;i++){
        
        sum_s[i] = sum_s[i-1] - closes[i-small_length] + closes[i];
        sma_s[i] = sum_s[i]/small_length;

    }


    temp_sum=0;
    for(int i=0;i<long_length;i++){
        temp_sum+=closes[i];
    }

    sum_l[long_length-1] = temp_sum;
    sma_l[long_length-1] = temp_sum/long_length;

    enum State { NONE, LONG, SHORT };
    State state = NONE;
    double entry = 0, profit = 0, total = 0;
    int trades = 0, profitable_profits = 0;


    for(int i=long_length;i<closes.size();i++){

        sum_s[i] = sum_s[i-1] - closes[i-small_length] + closes[i];
        sma_s[i] = sum_s[i]/small_length;

        sum_l[i] = sum_l[i-1] - closes[i-long_length] + closes[i];
        sma_l[i] = sum_l[i]/long_length;

        if(sma_s[i]>sma_l[i]){
            if(state==NONE){
                state=LONG;
                entry=closes[i];
            }
            else if(state==SHORT){
                state=NONE;
                profit = closes[i] - entry;

                total+=profit;
                if(profit>profit_threshold) profitable_profits++;
                trades++;
            }
        }

        else if (sma_s[i]<sma_l[i]){
            if(state==NONE){
                state=SHORT;
                entry=closes[i];
            }
            else if(state==LONG){
                state=NONE;
                profit = entry - closes[i];

                total+=profit;
                if(profit>profit_threshold) profitable_profits++;
                trades++;
            }
        }

    }

    if(state==SHORT){
        state=NONE;
        profit = entry - closes.back();

        total+=profit;
        if(profit>profit_threshold) profitable_profits++;
        trades++;
    }

    if(state==LONG){
        state=NONE;
        profit = closes.back() - entry;

        total+=profit;
        if(profit>profit_threshold) profitable_profits++;
        trades++;
    }

    double success_rate = trades>0 ? profitable_profits*100/trades : 0;
    double avg_returns = total/trades;

    return {success_rate,avg_returns,trades,total};

}
