/*int ema(vector<double> values,int index,int period){
    
    if(index<period){
        
        double sum=0; 
        for(int i=0;i<index;i++){
            sum+=values[i];
        }
        return sum/index;

    }

    else{
        double sum=0; 
        for(int i=0;i<index;i++){
            sum+=values[i];
        }
        return sum/index;
    }
}
*/

#include <vector>
#include<iostream>
#include "macd.h"
using namespace std;


double ema(double ema_prev,double alpha,double curr_val){

    return ema_prev*(1-alpha) + curr_val*alpha;

}


TradeResult macd_implementation (const vector<Candle> &candles, double profit_threshold){

    vector<double> closes;
    
    for(auto i: candles){
        closes.push_back(i.close);
    }

    vector<double> ema_s(closes.size(), 0);
    vector<double> ema_l(closes.size(), 0);
    vector<double> macd(closes.size(), 0);
    vector<double> signal(closes.size(), 0); //made vectors for the slow n fast emas
    
    double small_length = 12;
    double long_length= 26;
    double signal_length= 9;
    
    double a_12 = 2.0/(small_length+1); //alpha for 12 days
    double a_26 = 2.0/(long_length+1); //alpha for 26 days
    double a_9 = 2.0/(signal_length+1);


    double temp_sum=0;
    for(int i=0;i<small_length;i++){
        temp_sum+=closes[i];
    }

    ema_s[small_length-1] = temp_sum/small_length;

    
    for(int i=small_length;i<(long_length+signal_length);i++){

        ema_s[i] = (ema(ema_s[i-1],a_12,closes[i]));

    }


    temp_sum=0;
    for(int i=0;i<long_length;i++){
        temp_sum+=closes[i];
    }

    ema_l[long_length-1] = temp_sum/long_length;

    for(int i=long_length;i<(long_length+signal_length);i++){

        ema_l[i] = (ema(ema_l[i-1],a_26,closes[i]));

    }

    temp_sum=0;
    for(int i=long_length;i<(long_length+signal_length);i++){

        macd[i] = (ema_s[i] - ema_l[i]);

        temp_sum += macd[i];
    }

    signal[long_length+signal_length-1] = temp_sum/signal_length;

    enum State { NONE, LONG, SHORT };
    State state = NONE;
    double entry = 0, profit = 0, total = 0;
    int trades = 0, profitable_profits = 0;


    for(int i=(long_length+signal_length);i<closes.size();i++){

        ema_s[i] = (ema(ema_s[i-1],a_12,closes[i]));
        ema_l[i] = (ema(ema_l[i-1],a_26,closes[i]));

        macd[i] = (ema_s[i] - ema_l[i]);

        signal[i] = (ema(signal[i-1],a_9,macd[i]));

        if(macd[i]>signal[i]){
            if(state==NONE){
                state=LONG;
                entry=closes[i];
            }
            else if(state==SHORT){
                state=NONE;
                profit = closes[i] - entry;

                total+=profit;
                if(profit>profit_threshold) profitable_profits++;
                trades++;

cout << " Entry: " << entry 
     << " Exit: " << closes[i] 
     << " Profit: " << profit << endl;

            }
        }

        else if (macd[i]<signal[i]){
            if(state==NONE){
                state=SHORT;
                entry=closes[i];
            }
            else if(state==LONG){
                state=NONE;
                profit = entry - closes[i];

                total+=profit;
                if(profit>profit_threshold) profitable_profits++;
                trades++;

		cout << " Entry: " << entry 
     << " Exit: " << closes[i] 
     << " Profit: " << profit << endl;
            }
        }


    }

    if(state==SHORT){
        state=NONE;
        profit = entry - closes.back();

        total+=profit;
        if(profit>profit_threshold) profitable_profits++;
        trades++;
    }

    if(state==LONG){
        state=NONE;
        profit = closes.back() - entry;

        total+=profit;
        if(profit>profit_threshold) profitable_profits++;
        trades++;
    }

    double success_rate = trades>0 ? profitable_profits*100/trades : 0;
    double avg_returns = total/trades;

    return {success_rate,avg_returns,trades,total};

}
