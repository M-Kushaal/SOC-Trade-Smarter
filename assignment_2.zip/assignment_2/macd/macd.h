#ifndef MACD_H
#define MACD_H

#include <vector>
#include <string>

using namespace std;

struct Candle {string date; double open; double high; double low; double close; };

struct TradeResult {
    double success_rate;
    double avg_returns;
    int trades;
    double total;
};

TradeResult macd_implementation(const vector<Candle>& candles, double profit_threshold);

#endif

